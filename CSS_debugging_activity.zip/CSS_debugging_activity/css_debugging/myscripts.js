function myFunction1() {
    var x = document.getElementById("hint1");
    if (x.innerHTML === "Hint 1: ") {
      x.innerHTML = "Hint 1: X Y Selector";
    } else {
      x.innerHTML = "Hint 1: ";
    }
  }
  
  function myFunction2() {
    var x = document.getElementById("hint2");
    if (x.innerHTML === "Hint 2: ") {
      x.innerHTML = "Hint 2: X + Y Selector";
    } else {
      x.innerHTML = "Hint 2: ";
    }
  }
  
  function myFunction3() {
    var x = document.getElementById("hint3");
    if (x.innerHTML === "Hint 3: ") {
      x.innerHTML = "Hint 3: X > Y Selector";
    } else {
      x.innerHTML = "Hint 3: ";
    }
  }
  function myFunction4() {
    var x = document.getElementById("hint4");
    if (x.innerHTML === "Hint 4: ") {
      x.innerHTML = "Hint 4: X ~ Y Selector";
    } else {
      x.innerHTML = "Hint 4: ";
    }
  }
  
  function myFunction1() {
    var x = document.getElementById("hint1");
    if (x.innerHTML === "Hint 1: ") {
      x.innerHTML = "Hint 1: X Y Selector";
    } else {
      x.innerHTML = "Hint 1: ";
    }
  }
  
  function myFunction2() {
    var x = document.getElementById("hint2");
    if (x.innerHTML === "Hint 2: ") {
      x.innerHTML = "Hint 2: X + Y Selector";
    } else {
      x.innerHTML = "Hint 2: ";
    }
  }
  
  function myFunction3() {
    var x = document.getElementById("hint3");
    if (x.innerHTML === "Hint 3: ") {
      x.innerHTML = "Hint 3: X > Y Selector";
    } else {
      x.innerHTML = "Hint 3: ";
    }
  }
  function myFunction4() {
    var x = document.getElementById("hint4");
    if (x.innerHTML === "Hint 4: ") {
      x.innerHTML = "Hint 4: X ~ Y Selector";
    } else {
      x.innerHTML = "Hint 4: ";
    }
  }
  
    